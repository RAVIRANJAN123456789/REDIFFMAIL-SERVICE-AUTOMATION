package com.liveproject;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import java.util.concurrent.TimeUnit;
 

public class TestNGAsserts {
	public WebDriver driver=new ChromeDriver();
	@Test
	public void loginRediff() throws Exception {
				
				
			    
			    //WebDriver driver=new ChromeDriver();
			    System.setProperty("webdriver.gecko.driver","C:\\Users\\Ravi\\eclipse-workspace\\SELENIUM PROJECT\\geckodriver.exe");
				driver.manage().window().maximize();
				driver.get("https://www.rediff.com/");
				
				driver.get("https://mail.rediff.com/cgi-bin/login.cgi");
				//Finding Signin and Clicking on it
				//driver.findElement(By.xpath("/html/body/div[2]/div/div[3]/p/a[1]")).click();
				driver.manage().window().maximize();
				driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);	
				//Finding username and entering its value
				//driver.findElement(By.xpath("/html/body/div[2]/div/div[3]/p/a[1]"));
				driver.findElement(By.xpath("/html/body/div/div[1]/div[1]/div[2]/form/div[1]/div[2]/div[1]/div[2]/input")).sendKeys("test1111222233334444");
				driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
				//password
				driver.findElement(By.xpath("/html/body/div/div[1]/div[1]/div[2]/form/div[1]/div[2]/div[2]/div[2]/input[1]")).sendKeys("Automation@1");
				driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);	
			    driver.findElement(By.xpath("/html/body/div/div[1]/div[1]/div[2]/form/div[1]/div[2]/div[2]/div[2]/input[2]")).click();
			    driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
			    //driver.findElement(By.xpath("/html/body/div/div[3]/div/form/div[7]/div/input")).click();
			    //driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
		 	    driver.manage().timeouts().implicitlyWait(2000,TimeUnit.MILLISECONDS);		
			  	//Verifying whether we are loggedin or not
			    String testing="TESTING";
			    driver.getTitle();
			    AssertJUnit.assertEquals(driver.findElement(By.xpath("/html/body/div[4]/div[1]/div/div[2]/span/cite/a")).getText(),testing);
			    driver.manage().timeouts().implicitlyWait(1,TimeUnit.SECONDS);	
			    driver.findElement(By.xpath("/html/body/div[4]/div[2]/div[2]/div[1]/div[1]/div[2]/div[2]/h4")).click();
			    driver.findElement(By.xpath("/html/body/div[4]/div[2]/div[2]/div[2]/div[6]/div/div[4]/div/div/div/div/table/thead/tr/th[2]"));
			    Thread.sleep(2000);
			    String date="Wednesday 6/1";
			    AssertJUnit.assertEquals(driver.findElement(By.xpath("/html/body/div[4]/div[2]/div[2]/div[2]/div[6]/div/div[4]/div/div/div/div/table/thead/tr/th[2]")).getText(),date);
			    Thread.sleep(2000);	
			    //Assert.assertEquals(driver.findElement(By.xpath("/html/body/div[4]/div[1]/div/cite/a")).getText(),"rediff.com");
			    //Thread.sleep(1);
			    System.out.println("Logging out");
			    driver.findElement(By.xpath("/html/body/div[4]/div[1]/div/div[2]/a[2]")).click();
			    Thread.sleep(2000);
	}

			    @AfterTest
				protected void tearDown() throws Exception {
					Thread.sleep(2000);
				    driver.quit();
				    driver = null;
				}
			}




/*
package com.liveproject;

import org.testng.annotations.Test;
import org.testng.Assert;
import org.testng.AssertJUnit;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
//import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestNGAsserts {
	TestNGAsserts(){}
	//WebDriver driver=null;
	//WebDriver driver = new ChromeDriver();
	//WebDriver driver = new ChromeDriver();
	WebDriver driver = new ChromeDriver();
	
	
	
   @Test
   public void loginRediff() throws Exception {
		
		
	    
	    
	    System.setProperty("webdriver.chrome.driver","C:\\Users\\Ravi\\eclipse-workspace\\SELENIUM PROJECT\\chromedriver.exe");
		driver.manage().window().maximize();
		driver.get("https://www.rediff.com/");
		
		driver.get("https://mail.rediff.com/cgi-bin/login.cgi");
		//Finding Signin and Clicking on it
		//driver.findElement(By.xpath("/html/body/div[2]/div/div[3]/p/a[1]")).click();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);	
		//Finding username and entering its value
		//driver.findElement(By.xpath("/html/body/div[2]/div/div[3]/p/a[1]"));
		driver.findElement(By.xpath("/html/body/div/div[1]/div[1]/div[2]/form/div[1]/div[2]/div[1]/div[2]/input")).sendKeys("test1111222233334444");
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		//password
		driver.findElement(By.xpath("/html/body/div/div[1]/div[1]/div[2]/form/div[1]/div[2]/div[2]/div[2]/input[1]")).sendKeys("Automation@1");
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);	
	    driver.findElement(By.xpath("/html/body/div/div[1]/div[1]/div[2]/form/div[1]/div[2]/div[2]/div[2]/input[2]")).click();
	    driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	    driver.findElement(By.xpath("/html/body/div/div[3]/div/form/div[7]/div/input")).click();
	    //driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
 	    driver.manage().timeouts().implicitlyWait(2000,TimeUnit.MILLISECONDS);		
	  	//Verifying whether we are loggedin or not
	    String testing="TESTING";
	    driver.getTitle();
	    AssertJUnit.assertEquals(driver.findElement(By.xpath("/html/body/div[4]/div[1]/div/div[2]/span/cite/a")).getText(),testing);
	    driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);	
	    driver.findElement(By.xpath("/html/body/div[4]/div[2]/div[2]/div[1]/div[1]/div[2]/div[2]/h4")).click();
	    driver.switchTo().frame("https://f5mail.rediff.com/ajaxprism/container?angular=1&els=4204b07e1f01227288076a5051ec0818&user_size=1");
	    String date="Saturday 2/1";
	    Thread.sleep(2000);
	    AssertJUnit.assertEquals(driver.findElement(By.xpath("/html/body/div[4]/div[2]/div[2]/div[2]/div[6]/div/div[4]/div/div/div/div/table/thead/tr/th[2]")).getText(),date);
	    Thread.sleep(2000);	
	    Assert.assertEquals(driver.findElement(By.xpath("/html/body/div[2]/div/div[1]/span")).getText(),"rediff.com");
	    Thread.sleep(100);
	    driver.quit();
	    //driver.quit();
	    //driver.quit();
	}
}
*/
   //Test fails since the date changed
/*   
 @AfterTest
   public void closebrowser() throws InterruptedException
   {
	 
	 
	  Thread.sleep(10000);
	  driver.quit();
   }
   
   
}
*/


//package softwareTestingMaterial;

	/*
	@Test
	public void testNGAsserts() throws Exception{
		System.setProperty("webdriver.gecko.driver","C:\\Users\\Ravi\\eclipse-workspace\\SELENIUM PROJECT\\geckodriver.exe");
		WebDriver driver = new FirefoxDriver();
		//Test Condition 1: If Page title matches with actualTitle then it finds email title and enters the value which we pass
		driver.get("https://www.gmail.com");
		String actualTitle = "Gmail";
		AssertJUnit.assertEquals(driver.getTitle(), actualTitle);
		Thread.sleep(200);
		//driver.findElement(By.xpath("//*[@id='Email']")).sendKeys("SoftwareTestingMaterial.com");
		//Test Condition 2: If page title didnt match with actualTitle then script throws an exception
		//Thread.sleep(2000);
		//driver.get("https://www.gmail.com");
		//actualTitle = "Gmail";
		//Thread.sleep(2000);
		//Assert.assertEquals(driver.getTitle(), actualTitle, "Title not matched");//Test must fail
		AssertJUnit.assertEquals(driver.getTitle(), actualTitle);
		
		//create an object of Workbook and pass the FileInputStream object into it to create a pipeline between the sheet and eclipse.
		FileInputStream fis = new FileInputStream("C:\\Users\\Ravi\\Documents\\Test.xlsx");
		try (XSSFWorkbook workbook = new XSSFWorkbook(fis)) {
			//call the getSheet() method of Workbook and pass the Sheet Name here. 
			//In this case I have given the sheet name as �TestData� 
			        //or if you use the method getSheetAt(), you can pass sheet number starting from 0. Index starts with 0.
			XSSFSheet sheet = workbook.getSheet("Sheet1");
			//XSSFSheet sheet = workbook.getSheetAt(0);
			//Now create a row number and a cell where we want to enter a value. 
			//Here im about to write my test data in the cell B2. It reads Column B as 1 and Row 2 as 1. Column and Row values start from 0.
			//The below line of code will search for row number 2 and column number 2 (i.e., B) and will create a space. 
			//The createCell() method is present inside Row class.
			Row row = sheet.createRow(1);
			Cell cell = row.createCell(1);
			//Now we need to find out the type of the value we want to enter. 
			        //If it is a string, we need to set the cell type as string 
			        //if it is numeric, we need to set the cell type as number
			//cell.setCellType(Cell.SRING);
			cell.setCellValue("SoftwareTestingMaterial.com");
			FileOutputStream fos = new FileOutputStream("C:\\Users\\Ravi\\Documents\\Test.xlsx");
			workbook.write(fos);
			fos.close();
		}
		System.out.println("END OF WRITING DATA IN EXCEL -1");
		driver.quit();
	}
	*/	
		
		
		
	
			   /* 
			    
			    FileInputStream fis = new FileInputStream("C:\\Users\\Ravi\\Documents\\Test.xlsx");
				try (XSSFWorkbook workbook = new XSSFWorkbook(fis)) {
					//call the getSheet() method of Workbook and pass the Sheet Name here. 
					//In this case I have given the sheet name as �TestData� 
					        //or if you use the method getSheetAt(), you can pass sheet number starting from 0. Index starts with 0.
					XSSFSheet sheet = workbook.getSheetAt(0);
					//XSSFSheet sheet = workbook.getSheetAt(0);
					//Now create a row number and a cell where we want to enter a value. 
					//Here im about to write my test data in the cell B2. It reads Column B as 1 and Row 2 as 1. Column and Row values start from 0.
					//The below line of code will search for row number 2 and column number 2 (i.e., B) and will create a space. 
					//The createCell() method is present inside Row class.
					Row row = sheet.createRow(2);
					Cell cell = row.createCell(1);
					//Now we need to find out the type of the value we want to enter. 
					        //If it is a string, we need to set the cell type as string 
					        //if it is numeric, we need to set the cell type as number
					//cell.setCellType(Cell.SRING);
					cell.setCellValue("Reddiff.com");
					FileOutputStream fos = new FileOutputStream("C:\\Users\\Ravi\\Documents\\Test.xlsx");
					workbook.write(fos);
					fos.close();
				}
				*/
			    
			    
			    //driver.close();
			    
			
	
/*	@AfterTest
	public void closebrowser()
	{

	    //WebDriver driver=new ChromeDriver();
	    //System.setProperty("webdriver.gecko.driver","C:\\Users\\Ravi\\eclipse-workspace\\SELENIUM PROJECT\\geckodriver.exe");
		driver.quit();
	}
	*/
	//driver.quit();
	



